ln -s /usr/lib/x86_64-linux-gnu/libtiff.so.5.2.0 libtiff.so.3
setenv LD_LIBRARY_PATH ~/EE271/EE271_project/assignment2/
make run_dc  
