



#make run RUN="+testname=$EE271_VECT/vec_271_01_sv_short.dat"
#diff sv_out.ppm $EE271_VECT/vec_271_01_sv_short_ref.ppm

make run RUN="+testname=$EE271_VECT/vec_271_01_sv.dat"
diff sv_out.ppm $EE271_VECT/vec_271_01_sv_ref.ppm

